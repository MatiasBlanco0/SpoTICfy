# SpoTICfy
 
## Trabajo Practico de Back-end
## Integrantes:
Matias Blanco y Matias Singermann y Sofia Alcacer Mackinlay
